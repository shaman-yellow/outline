
# Findsimilar

Use `fastdup` as backend for similar picture finding.
